'use strict';

/**
 * Eine Sammlung von bereitgestellten Fragen und den dazugehörigen Antworten.
 */
var questions = [
    {
        question: 'was ist ihre lieblingsfarbe?',
        answer: 'blau'
    }
];

module.exports = questions;