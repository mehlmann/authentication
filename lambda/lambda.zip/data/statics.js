const STATIC_THRESHOLD = 1;
const DYNAMIC_THRESHOLD = 1;


module.exports = {
        STATIC_THRESHOLD,
        DYNAMIC_THRESHOLD
};