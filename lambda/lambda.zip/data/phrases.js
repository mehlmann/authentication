/**
 * Hier werden Konstanten definiert, welche öfters durch Alexa verwendet werden.
 */

const VERWENDEN = ['verwenden', 'benutzen', 'gebrauchen', 'nutzen', 'gebrauchen'];

module.exports = {VERWENDEN};