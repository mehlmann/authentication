/**
 * Hier werden Konstanten definiert, welche öfters durch Alexa verwendet werden.
 */

